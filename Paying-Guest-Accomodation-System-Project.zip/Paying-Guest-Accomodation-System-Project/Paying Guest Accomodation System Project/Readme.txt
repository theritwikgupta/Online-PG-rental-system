How to run the Paying Guest Accommodation System (PGAS) Project
1. Download the  zip file

2. Extract the file and copy pgas folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name pgasdb

6. Import pgasdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/pgas (frontend)

8. For owner panel

http://localhost/pgas /owner/login.php  (owner panel)

9. For admin panel

http://localhost/pgas /admin  (admin panel)

Credential for admin panel :

Username: admin Password: Test@123

Credential for user panel :

Username: testuser@gmail.com Password: Test@123

Credential for owner panel :

Username: pgtest@gmail.com Password: Test@123